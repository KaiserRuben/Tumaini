declare module "*.webp" {
    const value: any;
    export = value;
}
declare module 'vue3-markdown-it';