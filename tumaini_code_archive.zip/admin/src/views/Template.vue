<template>
</template>

<script lang="ts">
import Vue from 'vue';

export default Vue.extend({
  name: 'Template',
});
</script>
<style lang="scss">

</style>