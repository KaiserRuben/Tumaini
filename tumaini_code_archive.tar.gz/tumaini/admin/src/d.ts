declare module 'vue-material';
declare module "*.json";
declare module 'vue-multiselect';
declare module '@adapttive/vue-markdown';